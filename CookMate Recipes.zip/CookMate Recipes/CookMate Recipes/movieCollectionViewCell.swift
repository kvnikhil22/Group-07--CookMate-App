//
//  movieCollectionViewCell.swift
//  CookMate Recipes
//
//  Created by Krishnan Venkatesh,Nikhil on 5/4/22.
//

import UIKit

class movieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOutlet: UIImageView!

    func assignitems(with a: Recipe){
        
        imageViewOutlet.image = UIImage(named: a.imagePath)
    }
    
   

}
