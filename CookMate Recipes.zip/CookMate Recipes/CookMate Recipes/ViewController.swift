//
//  ViewController.swift
//  CookMate Recipes
//
//  Created by Konduri,Sai Deep on 4/6/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        logo.image = UIImage(named: "Logo")
        // Do any additional setup after loading the view.
    }


    @IBOutlet weak var logo: UIImageView!
}

