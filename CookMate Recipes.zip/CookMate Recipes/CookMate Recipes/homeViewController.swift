//
//  homeViewController.swift
//  CookMate Recipes
//
//  Created by Konduri,Sai Deep on 4/6/22.
//

import UIKit
import FirebaseDatabase





class homeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return trendList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionviewoutlet.dequeueReusableCell(withReuseIdentifier: "movie", for: indexPath) as! movieCollectionViewCell
        cell.assignitems(with: trendList[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        foundedItem = trendList[indexPath.row];
        self.performSegue(withIdentifier: "searchSegue", sender: self)
        
    }
    
   
    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
        
        breakfastImageOutlet.image = UIImage(named: "BreakFast")
        lunchImageOutelt.image = UIImage(named:  "Lunch")
        dinnerImageOutlet.image = UIImage(named:  "Dinner")
        smoothieimageOutlet.image = UIImage(named:  "blank")
        dessertImageOutlet.image = UIImage(named:  "blank")
        snacksImageOutlet.image = UIImage(named: "blank")

        // Do any additional setup after loading the view.
        
        collectionviewoutlet.delegate = self
        collectionviewoutlet.dataSource = self
        
        
        
    }
    
    @IBOutlet weak var collectionviewoutlet: UICollectionView!
    
    
    @IBOutlet weak var searchInput: UISearchBar!
    
    @IBAction func onSearch(_ sender: UIButton) {
        let inp = searchInput.text!
        
        for item in dinner{
            if item.name.contains(inp) {
                foundedItem = item
                break
            }
        }
        for item in lunch{
            if item.name.contains(inp) {
                foundedItem = item
                break
            }
        }
        for item in breakfast{
            if item.name.contains(inp) {
                foundedItem = item
                break
            }
        }
        
        if(foundedItem != nil) {
            print(foundedItem)
            self.performSegue(withIdentifier: "searchSegue", sender: self)
        }else{
            
            self.performSegue(withIdentifier: "noDataFound", sender: self)
        }
    }
    
    @IBOutlet weak var breakfastImageOutlet: UIImageView!
    
    @IBOutlet weak var lunchImageOutelt: UIImageView!
    
    @IBOutlet weak var dinnerImageOutlet: UIImageView!
    
    
    @IBOutlet weak var smoothieimageOutlet: UIImageView!
    
    @IBOutlet weak var dessertImageOutlet: UIImageView!
    
    @IBOutlet weak var snacksImageOutlet: UIImageView!
    var foundedItem: Recipe? = nil
    var trendList: [Recipe] = []
    func fetchData(){
    //Get a firebase database reference from the root of your firebase database
     let databaseRef = Database.database().reference()
               
    //Get the data from firebase database using observeSingleEvent(). This is useful
    //for data that only needs to be loaded once and isn't expected to change
    //frequently or require active listening.
            
    //parameter of: takes enum of type DataEventType, we are sending enum .value which
    //signifies any data changes at a location or, recursively, at any child node.
            
     databaseRef.observeSingleEvent(of: .value) { snapshot in
     //Assign snapshot.value to our var contacts which is of type NSDictionary
         let res = snapshot.value as! NSDictionary
         
         
         for (key, value) in res{
             if key as! String == "trend" {
                var trendIds = (value as! String).split(separator: " ")
                 
                 for id in trendIds{
                     
                     for item in dinner {
                         if item.id ?? "" == id {
                             self.trendList.append(item)
                         }
                      }
                     for item in lunch {
                         if item.id ?? "" == id {
                             self.trendList.append(item)
                         }
                      }
                     for item in breakfast {
                         if item.id ?? "" == id {
                             self.trendList.append(item)
                         }
                      }
                 }
                 
             }
             
             print(self.trendList);
             self.collectionviewoutlet.reloadData()
            
         }
         
     }
     }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          let transition = segue.identifier
          if transition == "lunchSegue"{
              let destination = segue.destination as! MenuViewController
              destination.tableData = lunch
          }
        
        if transition == "breakfastSegue"{
            let destination = segue.destination as! MenuViewController
            destination.tableData = breakfast
        }
        
        if transition == "dinnerSegue"{
            let destination = segue.destination as! MenuViewController
            destination.tableData = dinner
        }
        
        if transition == "searchSegue"{
            let destination = segue.destination as! DescriptionViewController
            destination.item = foundedItem
            foundedItem = nil
        }
      }

}
